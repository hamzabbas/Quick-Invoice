<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo e($welcome); ?></title>
</head>
<body>

<p><?php echo e($welcome); ?></p>
<h1>HI THERE</h1>
<p>its a testing mail</p>
    
</body>
</html><?php /**PATH D:\xampp\htdocs\sdm-multiple-1\sdm-multiple\resources\views\testingPdf.blade.php ENDPATH**/ ?>